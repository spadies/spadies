En este directorio estara el archivo de datos de
la instituci�n en formato .spa (o varios
archivos si la Instituci�n tiene varias sedes)
una vez la instituci�n haya sincronizado.
